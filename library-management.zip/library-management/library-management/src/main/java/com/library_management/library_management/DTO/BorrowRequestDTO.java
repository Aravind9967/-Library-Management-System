package com.library_management.library_management.DTO;

import java.time.LocalDate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowRequestDTO {

    @NotNull(message = "Book id is required")
    private Long bookId;

    @NotNull(message = "Member id is required")
    private Long memberId;

    @NotNull(message = "Borrow duration is required")
    @Min(value = 1, message = "Borrow duration must be at least 1 day")
    @Max(value = 90, message = "Borrow duration cannot exceed 90 days")
    private Integer borrowDurationDays;
}