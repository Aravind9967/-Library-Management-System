package com.library_management.library_management.Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.library_management.library_management.DTO.BookRequestDTO;
import com.library_management.library_management.DTO.BookResponseDTO;


public interface BookService {
    BookResponseDTO createBook(BookRequestDTO dto);
    BookResponseDTO getBookById(Long id);
    Page<BookResponseDTO> getAllBooks(Pageable pageable);
    Page<BookResponseDTO> searchBooks(String keyword, Pageable pageable);
    BookResponseDTO updateBook(Long id, BookRequestDTO dto);
    void deleteBook(Long id);
}