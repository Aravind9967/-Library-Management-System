package com.library_management.library_management.Exceptions;


public class BadRequestException extends RuntimeException {
 public BadRequestException(String message) {
     super(message);
 }
}