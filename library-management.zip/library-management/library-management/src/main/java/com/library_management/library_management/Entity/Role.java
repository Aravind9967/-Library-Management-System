package com.library_management.library_management.Entity;


public enum Role {
 LIBRARIAN, MEMBER
}