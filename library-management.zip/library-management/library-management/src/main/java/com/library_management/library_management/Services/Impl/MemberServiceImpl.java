package com.library_management.library_management.Services.Impl;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.library_management.library_management.DTO.MemberRequestDTO;
import com.library_management.library_management.DTO.MemberResponseDTO;
import com.library_management.library_management.Entity.Member;
import com.library_management.library_management.Exceptions.ResourceNotFoundException;
import com.library_management.library_management.Exceptions.BadRequestException;
import com.library_management.library_management.Repositories.MemberRepository;
import com.library_management.library_management.Services.MemberService;
// Adjust these imports to the actual packages in your project.
import com.library_management.library_management.Entity.BorrowRecord;
import com.library_management.library_management.Entity.BorrowStatus;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;

    @Override
    public MemberResponseDTO createMember(MemberRequestDTO dto) {

        String email = dto.getEmail().trim().toLowerCase();

        if (memberRepository.existsByEmail(email)) {
            throw new BadRequestException(
                "Member with email " + email + " already exists"
            );
        }

        Member member = Member.builder()
                .name(dto.getName())
                .email(email)
                .phone(dto.getPhone())
                .membershipDate(LocalDate.now())
                .build();

        return mapToResponse(memberRepository.save(member));
    }


    @Transactional(readOnly = true)
    public MemberResponseDTO getMemberById(Long id) {
        return mapToResponse(findMemberOrThrow(id));
    }

    @Transactional(readOnly = true)
    public Page<MemberResponseDTO> getAllMembers(Pageable pageable) {
        return memberRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

 
    public MemberResponseDTO updateMember(
            Long id, MemberRequestDTO dto) {

        Member member = findMemberOrThrow(id);
        String email = dto.getEmail().trim().toLowerCase();

        if (!member.getEmail().equalsIgnoreCase(email)
                && memberRepository.existsByEmail(email)) {
            throw new BadRequestException(
                "Member with email " + email + " already exists"
            );
        }

        member.setName(dto.getName());
        member.setEmail(email);
        member.setPhone(dto.getPhone());

        return mapToResponse(memberRepository.save(member));
    }

    public void deleteMember(Long id) {

        Member member = findMemberOrThrow(id);

        List<BorrowRecord> records = member.getBorrowRecords() == null
                ? Collections.emptyList()
                : member.getBorrowRecords();

        boolean hasActiveBorrows = records.stream()
                .anyMatch(record ->
                    record.getStatus() == BorrowStatus.BORROWED
                );

        if (hasActiveBorrows) {
            throw new BadRequestException(
                "Cannot delete member with active borrowed books"
            );
        }

        if (!records.isEmpty()) {
            throw new BadRequestException(
                "Cannot delete member with borrowing history"
            );
        }

        memberRepository.delete(member);
    }

    private Member findMemberOrThrow(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() ->
                    new ResourceNotFoundException(
                        "Member not found with id: " + id
                    )
                );
    }

    private MemberResponseDTO mapToResponse(Member member) {
        return MemberResponseDTO.builder()
                .id(member.getId())
                .name(member.getName())
                .email(member.getEmail())
                .phone(member.getPhone())
                .membershipDate(member.getMembershipDate())
                .build();
    }
}