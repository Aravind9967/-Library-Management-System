package com.library_management.library_management.Services;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import com.library_management.library_management.DTO.MemberRequestDTO;
import com.library_management.library_management.DTO.MemberResponseDTO;

public interface MemberService {
    MemberResponseDTO createMember(MemberRequestDTO dto);
    MemberResponseDTO getMemberById(Long id);
    Page<MemberResponseDTO> getAllMembers(Pageable pageable);
    MemberResponseDTO updateMember(Long id, MemberRequestDTO dto);
    void deleteMember(Long id);
}