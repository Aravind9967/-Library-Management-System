package com.library_management.library_management.DTO;

import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.library_management.library_management.Entity.BorrowStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BorrowResponseDTO {
    private Long id;
    private Long bookId;
    private String bookTitle;
    private Long memberId;
    private String memberName;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private BorrowStatus status;
    private BigDecimal fineAmount;
}