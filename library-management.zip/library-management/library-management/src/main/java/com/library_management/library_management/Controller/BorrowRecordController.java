package com.library_management.library_management.Controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.library_management.library_management.DTO.BorrowRequestDTO;
import com.library_management.library_management.DTO.BorrowResponseDTO;
import com.library_management.library_management.Services.BorrowRecordService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@RestController
@RequestMapping("/api/borrow-records")
@RequiredArgsConstructor
public class BorrowRecordController {

    private final BorrowRecordService borrowRecordService;

    @PostMapping
    @PreAuthorize("hasAnyRole('LIBRARIAN','MEMBER')")
    public ResponseEntity<BorrowResponseDTO> borrowBook(@Valid @RequestBody BorrowRequestDTO dto) {
        return new ResponseEntity<>(borrowRecordService.borrowBook(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}/return")
    @PreAuthorize("hasAnyRole('LIBRARIAN','MEMBER')")
    public ResponseEntity<BorrowResponseDTO> returnBook(@PathVariable Long id) {
        return ResponseEntity.ok(borrowRecordService.returnBook(id));
    }

    @GetMapping
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<Page<BorrowResponseDTO>> getAll(
            @PageableDefault(size = 10, sort = "borrowDate") Pageable pageable) {
        return ResponseEntity.ok(borrowRecordService.getAllBorrowRecords(pageable));
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<Page<BorrowResponseDTO>> getByMember(
            @PathVariable Long memberId,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(borrowRecordService.getBorrowRecordsByMember(memberId, pageable));
    }

    @GetMapping("/overdue")
    @PreAuthorize("hasRole('LIBRARIAN')")
    public ResponseEntity<List<BorrowResponseDTO>> getOverdue() {
        return ResponseEntity.ok(borrowRecordService.getOverdueRecords());
    }
}