package com.library_management.library_management.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.library_management.library_management.Entity.Member;

public interface MemberRepository extends JpaRepository<Member, Long> {
    Optional<Member> findByEmail(String email);
    boolean existsByEmail(String email);
}