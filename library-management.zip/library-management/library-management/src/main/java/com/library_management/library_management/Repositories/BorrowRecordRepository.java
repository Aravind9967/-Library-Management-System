package com.library_management.library_management.Repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.library_management.library_management.Entity.BorrowRecord;
import com.library_management.library_management.Entity.BorrowStatus;

public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, Long> {
    Page<BorrowRecord> findByMemberId(Long memberId, Pageable pageable);
    Page<BorrowRecord> findByBookId(Long bookId, Pageable pageable);
    List<BorrowRecord> findByStatusAndDueDateBefore(BorrowStatus status, LocalDate date);
    long countByMemberIdAndStatus(Long memberId, BorrowStatus status);
}