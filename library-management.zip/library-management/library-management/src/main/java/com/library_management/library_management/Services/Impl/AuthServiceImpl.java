package com.library_management.library_management.Services.Impl;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.library_management.library_management.DTO.AuthRequest;
import com.library_management.library_management.DTO.AuthResponse;
import com.library_management.library_management.DTO.RegisterRequest;
import com.library_management.library_management.Entity.User;
import com.library_management.library_management.Exceptions.BadRequestException;
import com.library_management.library_management.Repositories.UserRepository;
import com.library_management.library_management.Security.JwtUtil;
import com.library_management.library_management.Services.AuthService;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

 private final UserRepository userRepository;
 private final PasswordEncoder passwordEncoder;
 private final AuthenticationManager authenticationManager;
 private final JwtUtil jwtUtil;

 @Override
 public void register(RegisterRequest request) {
     if (userRepository.findByUsername(request.getUsername()).isPresent()) {
         throw new BadRequestException("Username already taken");
     }
     User user = User.builder()
             .username(request.getUsername())
             .password(passwordEncoder.encode(request.getPassword()))
             .role(request.getRole())
             .build();
     userRepository.save(user);
 }

 @Override
 public AuthResponse login(AuthRequest request) {
     authenticationManager.authenticate(
             new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

     User user = userRepository.findByUsername(request.getUsername())
             .orElseThrow(() -> new BadRequestException("Invalid credentials"));

     String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());

     return AuthResponse.builder()
             .token(token)
             .username(user.getUsername())
             .role(user.getRole().name())
             .build();
 }
}