package com.library_management.library_management.DTO;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookResponseDTO {
    private Long id;
    private String isbn;
    private String title;
    private String author;
    private Integer totalCopies;
    private Integer availableCopies;
    private LocalDate publishedDate;
}