package com.library_management.library_management.Services;

import com.library_management.library_management.DTO.AuthRequest;
import com.library_management.library_management.DTO.AuthResponse;
import com.library_management.library_management.DTO.RegisterRequest;

public interface AuthService {
    void register(RegisterRequest request);
    AuthResponse login(AuthRequest request);
}