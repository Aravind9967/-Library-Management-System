package com.library_management.library_management.Services.Impl;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.library_management.library_management.DTO.BookRequestDTO;
import com.library_management.library_management.DTO.BookResponseDTO;
import com.library_management.library_management.Entity.Book;
import com.library_management.library_management.Entity.BorrowStatus;
import com.library_management.library_management.Exceptions.BadRequestException;
import com.library_management.library_management.Exceptions.ResourceNotFoundException;
import com.library_management.library_management.Repositories.BookRepository;
import com.library_management.library_management.Services.BookService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;

    @Override
    public BookResponseDTO createBook(BookRequestDTO dto) {
        if (bookRepository.existsByIsbn(dto.getIsbn())) {
            throw new BadRequestException("Book with ISBN " + dto.getIsbn() + " already exists");
        }
        Book book = Book.builder()
                .isbn(dto.getIsbn())
                .title(dto.getTitle())
                .author(dto.getAuthor())
                .totalCopies(dto.getTotalCopies())
                .availableCopies(dto.getTotalCopies())
                .publishedDate(dto.getPublishedDate())
                .build();
        return mapToResponse(bookRepository.save(book));
    }

    @Override
    @Transactional
    public BookResponseDTO getBookById(Long id) {
        return mapToResponse(findBookOrThrow(id));
    }

    @Override
    @Transactional
    public Page<BookResponseDTO> getAllBooks(Pageable pageable) {
        return bookRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Override
    @Transactional
    public Page<BookResponseDTO> searchBooks(String keyword, Pageable pageable) {
        return bookRepository
                .findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(keyword, keyword, pageable)
                .map(this::mapToResponse);
    }

    @Override
    public BookResponseDTO updateBook(Long id, BookRequestDTO dto) {
        Book book = findBookOrThrow(id);

        int borrowedCopies = book.getTotalCopies() - book.getAvailableCopies();
        if (dto.getTotalCopies() < borrowedCopies) {
            throw new BadRequestException(
                    "Cannot reduce total copies below number currently borrowed (" + borrowedCopies + ")");
        }

        book.setTitle(dto.getTitle());
        book.setAuthor(dto.getAuthor());
        book.setIsbn(dto.getIsbn());
        book.setAvailableCopies(dto.getTotalCopies() - borrowedCopies);
        book.setTotalCopies(dto.getTotalCopies());
        book.setPublishedDate(dto.getPublishedDate());

        return mapToResponse(bookRepository.save(book));
    }

    @Override
    public void deleteBook(Long id) {
        Book book = findBookOrThrow(id);
        boolean hasActiveBorrows = book.getBorrowRecords().stream()
                .anyMatch(r -> r.getStatus() == BorrowStatus.BORROWED);
        if (hasActiveBorrows) {
            throw new BadRequestException("Cannot delete book with active borrow records");
        }
        bookRepository.delete(book);
    }

    private Book findBookOrThrow(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    private BookResponseDTO mapToResponse(Book book) {
        return BookResponseDTO.builder()
                .id(book.getId())
                .isbn(book.getIsbn())
                .title(book.getTitle())
                .author(book.getAuthor())
                .totalCopies(book.getTotalCopies())
                .availableCopies(book.getAvailableCopies())
                .publishedDate(book.getPublishedDate())
                .build();
    }




}