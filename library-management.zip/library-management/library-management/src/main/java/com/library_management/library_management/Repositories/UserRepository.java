package com.library_management.library_management.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library_management.library_management.Entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}