package com.library_management.library_management.Services;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.library_management.library_management.DTO.BorrowRequestDTO;
import com.library_management.library_management.DTO.BorrowResponseDTO;

public interface BorrowRecordService {
    BorrowResponseDTO borrowBook(BorrowRequestDTO dto);
    BorrowResponseDTO returnBook(Long borrowRecordId);
    Page<BorrowResponseDTO> getAllBorrowRecords(Pageable pageable);
    Page<BorrowResponseDTO> getBorrowRecordsByMember(Long memberId, Pageable pageable);
    List<BorrowResponseDTO> getOverdueRecords();
}