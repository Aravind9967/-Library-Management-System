package com.library_management.library_management.Services.Impl;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.library_management.library_management.DTO.BorrowRequestDTO;
import com.library_management.library_management.DTO.BorrowResponseDTO;
import com.library_management.library_management.Entity.Book;
import com.library_management.library_management.Entity.BorrowRecord;
import com.library_management.library_management.Entity.BorrowStatus;
import com.library_management.library_management.Entity.Member;
import com.library_management.library_management.Exceptions.BadRequestException;
import com.library_management.library_management.Exceptions.ResourceNotFoundException;
import com.library_management.library_management.Repositories.BookRepository;
import com.library_management.library_management.Repositories.BorrowRecordRepository;
import com.library_management.library_management.Repositories.MemberRepository;
import com.library_management.library_management.Services.BorrowRecordService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class BorrowRecordServiceImpl implements BorrowRecordService {

 private final BorrowRecordRepository borrowRecordRepository;
 private final BookRepository bookRepository;
 private final MemberRepository memberRepository;

 // Fine configuration — flat rate per day overdue.
 private static final BigDecimal FINE_PER_DAY = BigDecimal.valueOf(5.00);

 @Override
 public BorrowResponseDTO borrowBook(BorrowRequestDTO dto) {
     Book book = bookRepository.findById(dto.getBookId())
             .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + dto.getBookId()));
     Member member = memberRepository.findById(dto.getMemberId())
             .orElseThrow(() -> new ResourceNotFoundException("Member not found with id: " + dto.getMemberId()));

     if (book.getAvailableCopies() <= 0) {
         throw new BadRequestException("No available copies for book: " + book.getTitle());
     }

     book.setAvailableCopies(book.getAvailableCopies() - 1);
     bookRepository.save(book);

     BorrowRecord record = BorrowRecord.builder()
             .book(book)
             .member(member)
             .borrowDate(LocalDate.now())
             .dueDate(LocalDate.now().plusDays(dto.getBorrowDurationDays()))
             .status(BorrowStatus.BORROWED)
             .fineAmount(BigDecimal.ZERO)
             .build();

     return mapToResponse(borrowRecordRepository.save(record));
 }

 @Override
 public BorrowResponseDTO returnBook(Long id) {
     BorrowRecord record = borrowRecordRepository.findById(id)
             .orElseThrow(() -> new ResourceNotFoundException("Borrow record not found with id: " + id));

     if (record.getStatus() == BorrowStatus.RETURNED) {
         throw new BadRequestException("This book has already been returned");
     }

     LocalDate returnDate = LocalDate.now();
     record.setReturnDate(returnDate);
     record.setStatus(BorrowStatus.RETURNED);
     record.setFineAmount(calculateFine(record.getDueDate(), returnDate));

     Book book = record.getBook();
     book.setAvailableCopies(book.getAvailableCopies() + 1);
     bookRepository.save(book);

     return mapToResponse(borrowRecordRepository.save(record));
 }

 /**
  * Overdue fine calculation:
  * No fine if returned on/before due date.
  * Otherwise: fine = daysOverdue * FINE_PER_DAY
  */
 private BigDecimal calculateFine(LocalDate dueDate, LocalDate returnDate) {
     if (!returnDate.isAfter(dueDate)) {
         return BigDecimal.ZERO;
     }
     long overdueDays = ChronoUnit.DAYS.between(dueDate, returnDate);
     return FINE_PER_DAY.multiply(BigDecimal.valueOf(overdueDays));
 }

 @Override
 @Transactional(readOnly = true)
 public Page<BorrowResponseDTO> getAllBorrowRecords(Pageable pageable) {
     return borrowRecordRepository.findAll(pageable).map(this::mapToResponse);
 }

 @Override
 @Transactional(readOnly = true)
 public Page<BorrowResponseDTO> getBorrowRecordsByMember(Long memberId, Pageable pageable) {
     return borrowRecordRepository.findByMemberId(memberId, pageable).map(this::mapToResponse);
 }

 @Override
 @Transactional(readOnly = true)
 public List<BorrowResponseDTO> getOverdueRecords() {
     return borrowRecordRepository
             .findByStatusAndDueDateBefore(BorrowStatus.BORROWED, LocalDate.now())
             .stream()
             .map(this::mapToResponse)
             .collect(Collectors.toList());
 }

 private BorrowResponseDTO mapToResponse(BorrowRecord r) {
     return BorrowResponseDTO.builder()
             .id(r.getId())
             .bookId(r.getBook().getId())
             .bookTitle(r.getBook().getTitle())
             .memberId(r.getMember().getId())
             .memberName(r.getMember().getName())
             .borrowDate(r.getBorrowDate())
             .dueDate(r.getDueDate())
             .returnDate(r.getReturnDate())
             .status(r.getStatus())
             .fineAmount(r.getFineAmount())
             .build();
 }
}