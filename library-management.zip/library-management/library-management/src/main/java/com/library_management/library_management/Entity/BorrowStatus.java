package com.library_management.library_management.Entity;

public enum BorrowStatus {
    BORROWED, RETURNED, OVERDUE
}